package com.example.controlhorario
// ... (vollständiger Code für SQLite-Datenbank)
