package com.example.controlhorario
// ... (vollständiger Code wie zuvor, inklusive GPS-Logik und UI-Setup)
